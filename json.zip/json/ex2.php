<?php
$my["firstname"]="KIDAKARN";
$my["lastname"]="Intapanya";
$my["age"]="555";
$person = json_encode($my);
echo $person;
 ?>
