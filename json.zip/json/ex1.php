<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
<script type="text/javascript">
  var person ={
            "firstname":"Kidaakrn",
            "lastname":"Intapanya",
            "age":"21"
  };
  document.writeln("Your Nmae :"+person.firstname+" "+person.lastname+" age:"+person.age);//get display
  console.log("Your Nmae :"+person.firstname+" "+person.lastname+" age:"+person.age);
</script>
  </body>
</html>
